public class AtorJogador {

	protected Tabuleiro tab;
	protected AtorNetGames rede;
	protected string idUsuario;

	/**
	 * 
	 * @return 
	 */
	public int conectar() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public string obterDadosConexao() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param cod
	 * @return 
	 */
	public void notificarIrregularidade(int cod) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public int desconectar() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public int iniciarPartida() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public boolean avaliarInterrupcao() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param linha
	 * @param coluna
	 * @return 
	 */
	public int click(int linha, int coluna) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void enviarJogada() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void exibirEstado() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param posicao
	 * @return 
	 */
	public void tratarIniciarPartida(int posicao) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jogada
	 * @return 
	 */
	public void receberJogada(Lance jogada) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public ImagemDeTabuleiro informarEstado() {
		throw new UnsupportedOperationException();
	}

}