public class Posicao {

	protected Jogador ocupante;

	/**
	 * 
	 * @return 
	 */
	public boolean informarOcupada() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public Jogador informarOcupante() {
		throw new UnsupportedOperationException();
	}

}