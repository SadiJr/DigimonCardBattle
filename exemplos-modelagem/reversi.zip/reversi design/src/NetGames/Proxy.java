package NetGames;

public class Proxy {

	/**
	 * 
	 * @param objeto
	 * @return 
	 */
	public void addOuvinte(int objeto) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param servidor
	 * @param nome
	 * @return 
	 */
	public void conectar(int servidor, int nome) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void desconectar() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param numJog
	 * @return 
	 */
	public void iniciarPartida(int numJog) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jogada
	 * @return 
	 */
	public void enviaJogada(Jogada jogada) {
		throw new UnsupportedOperationException();
	}

}