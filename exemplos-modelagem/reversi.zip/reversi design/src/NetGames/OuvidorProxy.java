package NetGames;

public interface OuvidorProxy {

	/**
	 * 
	 * @param posicao
	 * @return 
	 */
	void iniciarNovaPartida(int posicao);

	/**
	 * 
	 * @param message
	 * @return 
	 */
	void finalizarPartidaComErro(string message);

	/**
	 * 
	 * @param message
	 * @return 
	 */
	void receberMensagem(string message);

	/**
	 * 
	 * @param jogada
	 * @return 
	 */
	void receberJogada(Jogada jogada);

	/**
	 * 
	 * @return 
	 */
	void tratarConexaoPerdida();

	/**
	 * 
	 * @param message
	 * @return 
	 */
	void tratarPartidaNaoIniciada(string message);

}