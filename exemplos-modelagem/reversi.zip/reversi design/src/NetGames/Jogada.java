package NetGames;

public interface Jogada {
}