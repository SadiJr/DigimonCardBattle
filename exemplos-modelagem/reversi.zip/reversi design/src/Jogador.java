public class Jogador {

	protected string nome;
	protected boolean simbolo;
	protected boolean daVez;
	protected boolean vencedor;

	/**
	 * 
	 * @return 
	 */
	public boolean informarDaVez() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public string informarNome() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public boolean informarVencedor() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public boolean informarSimbolo() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void iniciar() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param idJogador
	 * @return 
	 */
	public void assumirNome(string idJogador) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void habilitar() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param simbolo
	 * @return 
	 */
	public void assumirSimbolo(boolean simbolo) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void desabilitar() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void assumirVencedor() {
		throw new UnsupportedOperationException();
	}

}