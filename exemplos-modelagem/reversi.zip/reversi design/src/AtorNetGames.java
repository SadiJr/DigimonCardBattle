import NetGames.*;

public class AtorNetGames implements OuvidorProxy {

	protected AtorJogador interfaceGrafica;
	protected Proxy proxy;


	public boolean conectar(string servidor, string nome) {
		
	}


	public boolean desconectar() {
		
	}


	public void iniciarPartida() {
		
	}


	public void enviarJogada(Lance lance) {
		
	}


	public void iniciarNovaPartida(int posicao) {
		
	}


	public void informarNomeAdversario(string idUsuario) {
		
	}


	public void receberJogada(Lance jogada) {
		
	}

}