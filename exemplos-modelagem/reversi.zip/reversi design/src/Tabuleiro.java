public class Tabuleiro {

	protected Posicao posicoes;
	protected Jogador jogador1;
	protected Jogador jogador2;
	protected boolean partidaEmAndamento;
	protected boolean conectado;
	protected Posicao posicoesAfetadas;

	/**
	 * 
	 * @return 
	 */
	public boolean informarConectado() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param valor
	 * @return 
	 */
	public void estabelecerConectado(boolean valor) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public boolean informarEmAndamento() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param linha
	 * @param coluna
	 * @return 
	 */
	public int click(int linha, int coluna) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param linha
	 * @param coluna
	 * @return 
	 */
	public Lance informarJogada(int linha, int coluna) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public ImagemDeTabuleiro informarEstado() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void iniciar() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param idJogador
	 * @return 
	 */
	public void criarJogador(int idJogador) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param posicao
	 * @return 
	 */
	public void habilitar(int posicao) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void esvaziar() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jogada
	 * @return 
	 */
	public void receberJogada(Lance jogada) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param linha
	 * @param coluna
	 * @return 
	 */
	public int tratarLance(int linha, int coluna) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param linha
	 * @param coluna
	 * @return 
	 */
	public boolean verificarOcupada(int linha, int coluna) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param linha
	 * @param coluna
	 * @param direcao
	 * @return 
	 */
	public void avaliarDirecao(int linha, int coluna, int direcao) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void reverterPosicoesAfetadas() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void zerarPosicoesAfetadas() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param jogador
	 * @return 
	 */
	public boolean verificarPossibilidadeLance(Jogador jogador) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public void finalizarPartida() {
		throw new UnsupportedOperationException();
	}

}