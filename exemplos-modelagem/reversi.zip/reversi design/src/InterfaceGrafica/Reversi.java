package InterfaceGrafica;

public class Reversi {

	/**
	 * 
	 * @return 
	 */
	public void main() {
		throw new UnsupportedOperationException();
	}

}