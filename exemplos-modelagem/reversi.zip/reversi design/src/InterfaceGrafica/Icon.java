package InterfaceGrafica;

public class Icon {
}