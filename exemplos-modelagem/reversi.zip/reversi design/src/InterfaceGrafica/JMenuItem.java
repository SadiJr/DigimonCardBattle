package InterfaceGrafica;

public class JMenuItem {
}