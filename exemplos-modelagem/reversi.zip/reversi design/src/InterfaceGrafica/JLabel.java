package InterfaceGrafica;

public class JLabel {
}