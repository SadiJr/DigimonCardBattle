package InterfaceGrafica;

public class ImageIcon {
}