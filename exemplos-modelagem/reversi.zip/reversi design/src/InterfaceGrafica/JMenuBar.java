package InterfaceGrafica;

public class JMenuBar {
}