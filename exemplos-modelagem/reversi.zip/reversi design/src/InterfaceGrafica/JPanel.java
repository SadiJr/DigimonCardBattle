package InterfaceGrafica;

public class JPanel {
}