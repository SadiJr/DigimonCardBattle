package InterfaceGrafica;

public class JOptionPane {
}