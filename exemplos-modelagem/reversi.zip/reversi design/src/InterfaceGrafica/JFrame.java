package InterfaceGrafica;

public class JFrame {
}