package InterfaceGrafica;

public class JMenu {
}