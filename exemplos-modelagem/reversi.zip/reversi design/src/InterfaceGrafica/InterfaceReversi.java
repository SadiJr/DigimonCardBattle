package InterfaceGrafica;

public class InterfaceReversi extends JFrame {


	public void conectar() {
		throw new UnsupportedOperationException();
	}


	public void desconectar() {
		throw new UnsupportedOperationException();
	}


	public void iniciarPartida() {
		throw new UnsupportedOperationException();
	}


	public void click(int linha, int coluna) {
		throw new UnsupportedOperationException();
	}


	public void notificarResultado(int resultado) {
		throw new UnsupportedOperationException();
	}


	public void exibirEstado() {
		throw new UnsupportedOperationException();
	}


	public void atualizarWidgets(ImagemDeTabuleiro estado) {
		throw new UnsupportedOperationException();
	}

}