public class ImagemDeTabuleiro {

	protected string mensagem;
	protected string placar;
	protected int mapa;

	/**
	 * 
	 * @param mensagem
	 * @return 
	 */
	public void assumirMensagem(string mensagem) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param linha
	 * @param coluna
	 * @param valor
	 * @return 
	 */
	public void assumirValor(int linha, int coluna, int valor) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param placar
	 * @return 
	 */
	public void assumirPlacar(string placar) {
		throw new UnsupportedOperationException();
	}

}