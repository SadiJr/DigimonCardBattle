import NetGames.*;

public class Lance implements Jogada {

	protected int linha;
	protected int coluna;

	/**
	 * 
	 * @param linha
	 * @param coluna
	 * @return 
	 */
	public void assumir(int linha, int coluna) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public int informarLinha() {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return 
	 */
	public int informarColuna() {
		throw new UnsupportedOperationException();
	}

}