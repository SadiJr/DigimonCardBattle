package interfaceGrafica;

import javax.swing.JFrame;


public class Reversi {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		InterfaceReversi janela;
		janela = new InterfaceReversi();
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		janela.setVisible(true);
		}

}
