/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abalone;

import controller.AppAbalone;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import rede.AtorRede;
import view.AbaloneView;
import view.CarregarView;
import view.ConexaoView;

public class Abalone {


    public static void main(String[] args) {
    	
    	
   // 	JOptionPane.showMessageDialog(null, "teste");
        AppAbalone app = new AppAbalone();
//        new CarregarView(app);
        
        
 //       JOptionPane.showMessageDialog(null, "poxa");
        
        new AbaloneView(app);
        
  //      JOptionPane.showMessageDialog(null, "vair");
    //   AtorRede atorRede = new AtorRede(abaloneView);
   // 	new ConexaoView(atorRede, app);
    	

  //      UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
    }
}
