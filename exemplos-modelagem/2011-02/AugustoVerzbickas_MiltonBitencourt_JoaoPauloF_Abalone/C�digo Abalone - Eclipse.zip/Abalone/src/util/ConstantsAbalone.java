/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Milton Bittencourt
 */
public class ConstantsAbalone {
    
    //Contants de icones
    public final static String CAVEIRA = "/images/caveira.png";
    public final static String ALIEN = "/images/alien_32.png";
    public final static String PANDA = "/images/Panda.png";
    public final static String OBAMA = "/images/Barak-Obama-32.png";
    public final static String SOLDADO = "/images/GasSoldier.png";
    public final static String ALERTA = "/images/Gnome-Process-Stop-32.png";
    
}
