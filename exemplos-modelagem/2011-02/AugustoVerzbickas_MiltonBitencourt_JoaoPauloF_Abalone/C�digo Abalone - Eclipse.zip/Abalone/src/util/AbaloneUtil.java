/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import br.ufsc.inf.leobr.cliente.Jogada;
import java.util.ArrayList;
import model.Posicao;
import view.TabuleiroView;

/**
 * @author Milton Bittencourt
 */
public class AbaloneUtil implements Jogada {
    
    TabuleiroView tv;
    
    public AbaloneUtil(TabuleiroView _tv){
        tv = _tv;
    }
    
    public TabuleiroView getTv() {
        return tv;
    }

    public void setTv(TabuleiroView tv) {
        this.tv = tv;
    }
    
    public ArrayList<String[]> getArray(){
        
        ArrayList<String[]> al = new ArrayList<String[]>();
        
            String[] a0 = new String [4];
            a0[0] = "56";
            a0[1] = "2";
            a0[2] = "8";
            a0[3] = "4";
        
            String[] a1 = new String [4];
            a1[0] = "57";
            a1[1] = "2";
            a1[2] = "9";
            a1[3] = "5";
            
            String[] a2 = new String [4];
            a2[0] = "58";
            a2[1] = "2";
            a2[2] = "10";
            a2[3] = "6";
            
            String[] a3 = new String [4];
            a3[0] = "59";
            a3[1] = "2";
            a3[2] = "11";
            a3[3] = "7";
            
            String[] a4 = new String [4];
            a4[0] = "60";
            a4[1] = "2";
            a4[2] = "12";
            a4[3] = "8";
            
            String[] a5 = new String [4];
            a5[0] = "55";
            a5[1] = "3";
            a5[2] = "7";
            a5[3] = "4";

            String[] a6 = new String [4];
            a6[0] = "33";
            a6[1] = "3";
            a6[2] = "8";
            a6[3] = "5";
        
            String[] a7 = new String [4];
            a7[0] = "34";
            a7[1] = "3";
            a7[2] = "9";
            a7[3] = "6";
            
            String[] a8 = new String [4];
            a8[0] = "35";
            a8[1] = "3";
            a8[2] = "10";
            a8[3] = "7";
            
            String[] a9 = new String [4];
            a9[0] = "36";
            a9[1] = "3";
            a9[2] = "11";
            a9[3] = "8";
            
            String[] a10 = new String [4];
            a10[0] = "43";
            a10[1] = "3";
            a10[2] = "12";
            a10[3] = "9";
            
            String[] a11 = new String [4];
            a11[0] = "54";
            a11[1] = "4";
            a11[2] = "6";
            a11[3] = "4";

            String[] a12 = new String [4];
            a12[0] = "32";
            a12[1] = "4";
            a12[2] = "7";
            a12[3] = "5";
        
            String[] a13 = new String [4];
            a13[0] = "16";
            a13[1] = "4";
            a13[2] = "8";
            a13[3] = "6";
            
            String[] a14 = new String [4];
            a14[0] = "17";
            a14[1] = "4";
            a14[2] = "9";
            a14[3] = "7";
            
            String[] a15 = new String [4];
            a15[0] = "18";
            a15[1] = "4";
            a15[2] = "10";
            a15[3] = "8";
            
            String[] a16 = new String [4];
            a16[0] = "23";
            a16[1] = "4";
            a16[2] = "11";
            a16[3] = "9";
            
            String[] a17 = new String [4];
            a17[0] = "41";
            a17[1] = "4";
            a17[2] = "12";
            a17[3] = "10";

            String[] a18 = new String [4];
            a18[0] = "53";
            a18[1] = "5";
            a18[2] = "5";
            a18[3] = "4";
        
            String[] a19 = new String [4];
            a19[0] = "31";
            a19[1] = "5";
            a19[2] = "6";
            a19[3] = "5";
            
            String[] a20 = new String [4];
            a20[0] = "15";
            a20[1] = "5";
            a20[2] = "7";
            a20[3] = "6";
            
            String[] a21 = new String [4];
            a21[0] = "5";
            a21[1] = "5";
            a21[2] = "8";
            a21[3] = "7";
            
            String[] a22 = new String [4];
            a22[0] = "6";
            a22[1] = "5";
            a22[2] = "9";
            a22[3] = "8";
            
            String[] a23 = new String [4];
            a23[0] = "9";
            a23[1] = "5";
            a23[2] = "10";
            a23[3] = "9";
            
            
            String[] a24 = new String [4];
            a24[0] = "21";
            a24[1] = "5";
            a24[2] = "11";
            a24[3] = "10";
        
            String[] a25 = new String [4];
            a25[0] = "39";
            a25[1] = "5";
            a25[2] = "12";
            a25[3] = "11";
            
            String[] a26 = new String [4];
            a26[0] = "52";
            a26[1] = "6";
            a26[2] = "4";
            a26[3] = "4";
            
            String[] a27 = new String [4];
            a27[0] = "30";
            a27[1] = "6";
            a27[2] = "5";
            a27[3] = "5";
            
            String[] a28 = new String [4];
            a28[0] = "14";
            a28[1] = "6";
            a28[2] = "6";
            a28[3] = "6";
            
            String[] a29 = new String [4];
            a29[0] = "4";
            a29[1] = "6";
            a29[2] = "7";
            a29[3] = "7";

            String[] a30 = new String [4];
            a30[0] = "0";
            a30[1] = "6";
            a30[2] = "8";
            a30[3] = "8";
        
            String[] a31 = new String [4];
            a31[0] = "1";
            a31[1] = "6";
            a31[2] = "9";
            a31[3] = "9";
            
            String[] a32 = new String [4];
            a32[0] = "7";
            a32[1] = "6";
            a32[2] = "10";
            a32[3] = "10";
            
            String[] a33 = new String [4];
            a33[0] = "19";
            a33[1] = "6";
            a33[2] = "11";
            a33[3] = "11";
            
            String[] a34 = new String [4];
            a34[0] = "37";
            a34[1] = "6";
            a34[2] = "12";
            a34[3] = "12";
            
            String[] a35 = new String [4];
            a35[0] = "51";
            a35[1] = "7";
            a35[2] = "4";
            a35[3] = "5";

            String[] a36 = new String [4];
            a36[0] = "29";
            a36[1] = "7";
            a36[2] = "5";
            a36[3] = "6";
        
            String[] a37 = new String [4];
            a37[0] = "13";
            a37[1] = "7";
            a37[2] = "6";
            a37[3] = "7";
            
            String[] a38 = new String [4];
            a38[0] = "3";
            a38[1] = "7";
            a38[2] = "7";
            a38[3] = "8";
            
            String[] a39 = new String [4];
            a39[0] = "2";
            a39[1] = "7";
            a39[2] = "8";
            a39[3] = "9";
            
            String[] a40 = new String [4];
            a40[0] = "8";
            a40[1] = "7";
            a40[2] = "9";
            a40[3] = "10";
            
            String[] a41 = new String [4];
            a41[0] = "20";
            a41[1] = "7";
            a41[2] = "10";
            a41[3] = "11";

            String[] a42 = new String [4];
            a42[0] = "38";
            a42[1] = "7";
            a42[2] = "11";
            a42[3] = "12";
        
            String[] a43 = new String [4];
            a43[0] = "50";
            a43[1] = "8";
            a43[2] = "4";
            a43[3] = "6";
            
            String[] a44 = new String [4];
            a44[0] = "28";
            a44[1] = "8";
            a44[2] = "5";
            a44[3] = "7";
            
            String[] a45 = new String [4];
            a45[0] = "12";
            a45[1] = "8";
            a45[2] = "6";
            a45[3] = "8";
            
            String[] a46 = new String [4];
            a46[0] = "11";
            a46[1] = "8";
            a46[2] = "7";
            a46[3] = "9";
            
            String[] a47 = new String [4];
            a47[0] = "10";
            a47[1] = "8";
            a47[2] = "8";
            a47[3] = "10";
            
            String[] a48 = new String [4];
            a48[0] = "22";
            a48[1] = "8";
            a48[2] = "9";
            a48[3] = "11";
        
            String[] a49 = new String [4];
            a49[0] = "40";
            a49[1] = "8";
            a49[2] = "10";
            a49[3] = "12";
            
            String[] a50 = new String [4];
            a50[0] = "49";
            a50[1] = "9";
            a50[2] = "4";
            a50[3] = "7";
            
            String[] a51 = new String [4];
            a51[0] = "27";
            a51[1] = "9";
            a51[2] = "5";
            a51[3] = "8";
            
            String[] a52 = new String [4];
            a52[0] = "26";
            a52[1] = "9";
            a52[2] = "6";
            a52[3] = "9";
            
            String[] a53 = new String [4];
            a53[0] = "25";
            a53[1] = "9";
            a53[2] = "7";
            a53[3] = "10";

            String[] a54 = new String [4];
            a54[0] = "24";
            a54[1] = "9";
            a54[2] = "8";
            a54[3] = "11";
        
            String[] a55 = new String [4];
            a55[0] = "42";
            a55[1] = "9";
            a55[2] = "9";
            a55[3] = "12";
            
            String[] a56 = new String [4];
            a56[0] = "48";
            a56[1] = "10";
            a56[2] = "4";
            a56[3] = "8";
            
            String[] a57 = new String [4];
            a57[0] = "47";
            a57[1] = "10";
            a57[2] = "5";
            a57[3] = "9";
            
            String[] a58 = new String [4];
            a58[0] = "46";
            a58[1] = "10";
            a58[2] = "6";
            a58[3] = "10";
            
            String[] a59 = new String [4];
            a59[0] = "45";
            a59[1] = "10";
            a59[2] = "7";
            a59[3] = "11";

            String[] a60 = new String [4];
            a60[0] = "44";
            a60[1] = "10";
            a60[2] = "8";
            a60[3] = "12";
      
            String[] a61 = new String [4];
            a61[0] = "90";
            a61[1] = "1";
            a61[2] = "13";
            a61[3] = "8";
        
            String[] a62 = new String [4];
            a62[0] = "69";
            a62[1] = "2";
            a62[2] = "13";
            a62[3] = "9";
            
            String[] a63 = new String [4];
            a63[0] = "67";
            a63[1] = "3";
            a63[2] = "13";
            a63[3] = "10";
            
            String[] a64 = new String [4];
            a64[0] = "65";
            a64[1] = "4";
            a64[2] = "13";
            a64[3] = "11";
            
            String[] a65 = new String [4];
            a65[0] = "63";
            a65[1] = "5";
            a65[2] = "13";
            a65[3] = "12";
            
            String[] a66 = new String [4];
            a66[0] = "61";
            a66[1] = "6";
            a66[2] = "13";
            a66[3] = "13";

            String[] a67 = new String [4];
            a67[0] = "62";
            a67[1] = "7";
            a67[2] = "12";
            a67[3] = "13";
        
            String[] a68 = new String [4];
            a68[0] = "64";
            a68[1] = "8";
            a68[2] = "11";
            a68[3] = "13";
            
            String[] a69 = new String [4];
            a69[0] = "66";
            a69[1] = "9";
            a69[2] = "10";
            a69[3] = "13";
            
            String[] a70 = new String [4];
            a70[0] = "68";
            a70[1] = "10";
            a70[2] = "9";
            a70[3] = "13";
            
            String[] a71 = new String [4];
            a71[0] = "70";
            a71[1] = "11";
            a71[2] = "8";
            a71[3] = "13";
        
            String[] a72 = new String [4];
            a72[0] = "71";
            a72[1] = "11";
            a72[2] = "7";
            a72[3] = "12";
            
            String[] a73 = new String [4];
            a73[0] = "72";
            a73[1] = "11";
            a73[2] = "6";
            a73[3] = "11";
            
            String[] a74 = new String [4];
            a74[0] = "73";
            a74[1] = "11";
            a74[2] = "5";
            a74[3] = "10";
            
            String[] a75 = new String [4];
            a75[0] = "74";
            a75[1] = "11";
            a75[2] = "5";
            a75[3] = "9";
            
            String[] a76 = new String [4];
            a76[0] = "75";
            a76[1] = "11";
            a76[2] = "3";
            a76[3] = "8";

            String[] a77 = new String [4];
            a77[0] = "89";
            a77[1] = "1";
            a77[2] = "12";
            a77[3] = "7";
        
            String[] a78 = new String [4];
            a78[0] = "88";
            a78[1] = "1";
            a78[2] = "11";
            a78[3] = "6";
            
            String[] a79 = new String [4];
            a79[0] = "87";
            a79[1] = "1";
            a79[2] = "10";
            a79[3] = "5";
            
            String[] a80 = new String [4];
            a80[0] = "86";
            a80[1] = "1";
            a80[2] = "9";
            a80[3] = "4";
            
            String[] a81 = new String [4];
            a81[0] = "85";
            a81[1] = "1";
            a81[2] = "8";
            a81[3] = "3";
        
            String[] a82 = new String [4];
            a82[0] = "84";
            a82[1] = "2";
            a82[2] = "7";
            a82[3] = "3";
            
            String[] a83 = new String [4];
            a83[0] = "83";
            a83[1] = "3";
            a83[2] = "6";
            a83[3] = "3";
            
            String[] a84 = new String [4];
            a84[0] = "82";
            a84[1] = "4";
            a84[2] = "5";
            a84[3] = "3";
            
            String[] a85 = new String [4];
            a85[0] = "81";
            a85[1] = "5";
            a85[2] = "4";
            a85[3] = "3";
            
            String[] a86 = new String [4];
            a86[0] = "80";
            a86[1] = "6";
            a86[2] = "3";
            a86[3] = "3";

            String[] a87 = new String [4];
            a87[0] = "79";
            a87[1] = "7";
            a87[2] = "3";
            a87[3] = "4";
        
            String[] a88 = new String [4];
            a88[0] = "78";
            a88[1] = "8";
            a88[2] = "3";
            a88[3] = "5";
            
            String[] a89 = new String [4];
            a89[0] = "77";
            a89[1] = "9";
            a89[2] = "3";
            a89[3] = "6";
            
            String[] a90 = new String [4];
            a90[0] = "76";
            a90[1] = "10";
            a90[2] = "3";
            a90[3] = "7";
            
            al.add(a0);
            al.add(a1);
            al.add(a2);
            al.add(a3);
            al.add(a4);
            al.add(a5);
            al.add(a6);
            al.add(a7);
            al.add(a8);
            al.add(a9);
            al.add(a10);
            al.add(a11);
            al.add(a12);
            al.add(a13);
            al.add(a14);
            al.add(a15);
            al.add(a16);
            al.add(a17);
            al.add(a18);
            al.add(a19);
            al.add(a20);
            al.add(a21);
            al.add(a22);
            al.add(a23);
            al.add(a24);
            al.add(a25);
            al.add(a26);
            al.add(a27);
            al.add(a28);
            al.add(a29);
            al.add(a30);
            al.add(a31);
            al.add(a32);
            al.add(a33);
            al.add(a34);
            al.add(a35);
            al.add(a36);
            al.add(a37);
            al.add(a38);
            al.add(a39);
            al.add(a40);
            al.add(a41);
            al.add(a42);
            al.add(a43);
            al.add(a44);
            al.add(a45);
            al.add(a46);
            al.add(a47);
            al.add(a48);
            al.add(a49);
            al.add(a50);
            al.add(a51);
            al.add(a52);
            al.add(a53);
            al.add(a54);
            al.add(a55);
            al.add(a56);
            al.add(a57);
            al.add(a58);
            al.add(a59);
            al.add(a60);
            al.add(a61);
            al.add(a62);
            al.add(a63);
            al.add(a64);
            al.add(a65);
            al.add(a66);
            al.add(a67);
            al.add(a68);
            al.add(a69);
            al.add(a70);
            al.add(a71);
            al.add(a72);
            al.add(a73);
            al.add(a74);
            al.add(a75);
            al.add(a76);
            al.add(a77);
            al.add(a78);
            al.add(a79);
            al.add(a80);
            al.add(a81);
            al.add(a82);
            al.add(a83);
            al.add(a84);
            al.add(a85);
            al.add(a86);
            al.add(a87);
            al.add(a88);
            al.add(a89);
            al.add(a90);
            
                        
         return al;
    }
    
    public ArrayList<String> getProibidas(){
        ArrayList<String> pp = new ArrayList<String>();
        
        pp.add("70");
        pp.add("71");
        pp.add("72");
        pp.add("73");
        pp.add("74");
        pp.add("75");
        pp.add("68");
        pp.add("66");
        pp.add("64");
        pp.add("62");
        pp.add("76");
        pp.add("77");
        pp.add("78");
        pp.add("79");       
        pp.add("80");
        pp.add("81");
        pp.add("82");
        pp.add("83");
        pp.add("84");
        pp.add("85");
        pp.add("86");
        pp.add("87");
        pp.add("88");
        pp.add("89");
        pp.add("90");
        pp.add("63");
        pp.add("65");
        pp.add("67");
        pp.add("69");
        pp.add("61");

        return pp;
    }
    
    public Posicao[] buildPosicoes(){
        return tv.buildPosicoes();
    }
    
}
