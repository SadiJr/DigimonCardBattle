package view;


import javax.swing.JOptionPane;

import controller.AppAbalone;
import rede.AtorRede;

public class AbaloneView extends javax.swing.JFrame {
    
	private static final long serialVersionUID = 1L;
		MessagePanel messagePanel;  
        MenuPanel menuPanel;
        TabuleiroView tabuleiroView;
        AppAbalone app;

    public AbaloneView(AppAbalone app) {
    	

    	
        this.app = app;
        initComponents();
        configure();
        

        
        this.setSize (700, 700);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        
            
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        containerMessage = new javax.swing.JPanel();
        containerMenu = new javax.swing.JPanel();
        containerGame = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new java.awt.GridBagLayout());

        containerMessage.setBackground(new java.awt.Color(51, 204, 255));
        containerMessage.setLayout(new java.awt.GridLayout(1, 0));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.ipadx = 100;
        gridBagConstraints.ipady = 100;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        jPanel1.add(containerMessage, gridBagConstraints);

        containerMenu.setBackground(new java.awt.Color(153, 255, 102));
        containerMenu.setPreferredSize(new java.awt.Dimension(100, 100));
        containerMenu.setLayout(new java.awt.GridLayout(1, 0));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 60;
        gridBagConstraints.ipady = 119;
        jPanel1.add(containerMenu, gridBagConstraints);

        containerGame.setBackground(new java.awt.Color(0, 102, 0));
        containerGame.setPreferredSize(new java.awt.Dimension(100, 100));
        containerGame.setLayout(new java.awt.GridLayout(1, 0));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 485;
        gridBagConstraints.ipady = 446;
        gridBagConstraints.insets = new java.awt.Insets(7, 7, 7, 7);
        jPanel1.add(containerGame, gridBagConstraints);

        getContentPane().add(jPanel1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel containerGame;
    private javax.swing.JPanel containerMenu;
    private javax.swing.JPanel containerMessage;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

    private void configure() {
        
        AtorRede atorRede = new AtorRede(this);
        
       messagePanel = new MessagePanel(atorRede, app); 
        menuPanel = new MenuPanel(atorRede, app);       
       tabuleiroView = new TabuleiroView(app, atorRede);
        
        containerMessage.add(messagePanel, 0);
        containerMenu.add(menuPanel, 0);
        containerGame.add(tabuleiroView , 0);
    }
    
    public MessagePanel getMsgPanel(){
        return messagePanel;
    }

    public AppAbalone getApp() {
        return app;
    }

    public void setApp(AppAbalone app) {
        this.app = app;
    }

    public TabuleiroView getTabuleiroView() {
        return tabuleiroView;
    }

    public void setTabuleiroView(TabuleiroView tabuleiroView) {
        this.tabuleiroView = tabuleiroView;
    }
     
}
