package view;

import br.ufsc.inf.leobr.cliente.Jogada;
import controller.AppAbalone;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import model.JogadaAbalone;
import model.Jogador;
import model.Posicao;
import model.Tabuleiro;
import rede.AtorRede;
import util.AbaloneUtil;
import util.ConstantsAbalone;

public class TabuleiroView extends JPanel implements Jogada {

    double MIN_DIST;
    boolean primeiraVez;
    Posicao[] posicoes;
    ArrayList<String> posProibidas;
    double scale;
    AbaloneUtil abaloneUtil;
    Tabuleiro tabuleiro;
    AppAbalone app;
    AtorRede atorRede;
    boolean partidaIniciada;
    boolean primeiroAJogar = false;

    public TabuleiroView(AppAbalone app, AtorRede atorRede) {
        this.atorRede = atorRede;
        this.app = app;
        abaloneUtil = new AbaloneUtil(this);
        tabuleiro = new Tabuleiro(abaloneUtil);
        posProibidas = abaloneUtil.getProibidas();
        primeiraVez = true;
        scale = 3 / 4.0;
        MIN_DIST = 0;
        addMouseListener(this.switcher);
        app.setTabuleiro(tabuleiro);
        partidaIniciada = false;
        setBackground(Color.white);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        double w = getWidth();
        double h = getHeight();
        double R = Math.min(w, h) / 8;
        MIN_DIST = R / 4;

        double delta = (1.0 - scale) / 2;

        g2.translate(delta * w, delta * h);
        g2.scale(scale, scale);
        Rectangle r = getBounds();
        r.grow((int) (R * 3 / 4), (int) (R * 3 / 4));

        if (posicoes == null) {
            initHexCells(w, h, R, r);
        }

        if (primeiraVez && partidaIniciada) {

            String[] p1 = new String[14];
            p1[0] = "58";
            p1[1] = "59";
            p1[2] = "60";
            p1[3] = "57";
            p1[4] = "56";
            p1[5] = "55";
            p1[6] = "33";
            p1[7] = "34";
            p1[8] = "35";
            p1[9] = "36";
            p1[10] = "43";
            p1[11] = "16";
            p1[12] = "17";
            p1[13] = "18";

            String[] p2 = new String[14];
            p2[0] = "44";
            p2[1] = "45";
            p2[2] = "46";
            p2[3] = "47";
            p2[4] = "48";
            p2[5] = "49";
            p2[6] = "27";
            p2[7] = "26";
            p2[8] = "25";
            p2[9] = "24";
            p2[10] = "42";
            p2[11] = "12";
            p2[12] = "11";
            p2[13] = "10";

            String[] p3 = new String[30];
            p3[0] = "70";
            p3[1] = "71";
            p3[2] = "72";
            p3[3] = "73";
            p3[4] = "74";
            p3[5] = "75";
            p3[6] = "68";
            p3[7] = "66";
            p3[8] = "64";
            p3[9] = "62";
            p3[10] = "76";
            p3[11] = "77";
            p3[12] = "78";
            p3[13] = "79";
            p3[14] = "80";
            p3[15] = "81";
            p3[16] = "82";
            p3[17] = "83";
            p3[18] = "84";
            p3[19] = "85";
            p3[20] = "86";
            p3[21] = "87";
            p3[22] = "88";
            p3[23] = "89";
            p3[24] = "90";
            p3[25] = "63";
            p3[26] = "65";
            p3[27] = "67";
            p3[28] = "69";
            p3[29] = "61";

            Jogador oc = new Jogador();
            oc.setTipoDaPeca(ConstantsAbalone.ALERTA);


            if (primeiroAJogar) {
                createInitPositions(p1, app.getJogadorLocal());
                createInitPositions(p2, app.getJogadorAdvesario());
            } else {
                createInitPositions(p2, app.getJogadorLocal());
                createInitPositions(p1, app.getJogadorAdvesario());
            }

            createInitPositions(p3, oc);

            primeiraVez = false;
        }


        for (int i = 0; i < posicoes.length; i++) {
            posicoes[i].draw(g2);
        }

        g2.translate(-delta * w, -delta * h);
        g2.scale(1.0 / scale, 1.0 / scale);

    }

    private void createInitPositions(String[] p1, Jogador jogador) {

        ArrayList<String[]> lista = abaloneUtil.getArray();

        for (int i = 0; i < p1.length; i++) {
            for (int j = 0; j < posicoes.length; j++) {
                if (posicoes[j].getId().equals(p1[i])) {
                    posicoes[j].setOcupado(true);
                    posicoes[j].setJogador(jogador);
                }
            }
        }

        for (int i = 0; i < lista.size(); i++) {
            for (int j = 0; j < posicoes.length; j++) {
                if (posicoes[j].getId().equals(lista.get(i)[0])) {
                    posicoes[j].setLinha(lista.get(i)[1]);
                    posicoes[j].setDiagonalEsquerda(lista.get(i)[2]);
                    posicoes[j].setDiagonalDireita(lista.get(i)[3]);
                }
            }
        }

    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(500, 500);
    }

    private void initHexCells(double w, double h, double R, Rectangle range) {

        R = 30;

        Path2D.Double path = getPath(w / 2, h / 2, R);
        Rectangle2D bounds = path.getBounds2D();

        double radius = Math.min(bounds.getWidth(), bounds.getHeight());

        List<Point2D.Double> list =
                getAllPoints(bounds.getCenterX(),
                bounds.getCenterY(), radius, range);

        posicoes = new Posicao[list.size()];

        double theta = true ? -Math.PI / 6 : 0;
        for (int i = 0; i < list.size(); i++) {
            String id = String.valueOf(i);
            Point2D.Double p = list.get(i);
            double x = p.x - w / 2;
            double y = p.y - h / 2;
            AffineTransform at =
                    AffineTransform.getTranslateInstance(x, y);
            Shape s = at.createTransformedShape(path);
            String[] adjacentIds = getNeighbors(i, radius, list);
            posicoes[i] = new Posicao(id, p, s, theta, adjacentIds);
        }
    }

    private String[] getNeighbors(int index, double radius, List<Point2D.Double> list) {

        String[] ids = new String[6];
        double thetaInc = true ? Math.PI / 3 : Math.PI / 6;
        Point2D.Double center = list.get(index);
        radius += 1;
        Ellipse2D.Double e = new Ellipse2D.Double(center.x - radius,
                center.y - radius,
                2 * radius, 2 * radius);
        for (int i = 0; i < list.size(); i++) {
            if (i == index) {
                continue;
            }
            Point2D.Double p = list.get(i);
            if (e.contains(p)) {
                double phi = Math.atan2(p.y - center.y, p.x - center.x);
                if (phi < 0.0 && phi < -0.0001) {
                    phi += 2 * Math.PI;
                }
                int j = (int) Math.round(phi / thetaInc);

                if (j < 0) {
                    j += 5;
                }
                if (j < ids.length) {
                    ids[j] = String.valueOf(i);
                }
            }
        }
        return ids;
    }

    private List<Point2D.Double> getAllPoints(double cx, double cy,
            double radius,
            Rectangle range) {
        Point2D.Double center = new Point2D.Double(cx, cy);
        List<Point2D.Double> list = new ArrayList<Point2D.Double>();
        list.add(center);
        Point2D.Double[] points = {new Point2D.Double(cx, cy)};
        List<Point2D.Double> subList = null;
        do {
            List<Point2D.Double> nextPoints = new ArrayList<Point2D.Double>();
            for (int i = 0; i < points.length; i++) {
                subList = getPoints(points[i].x, points[i].y,
                        radius, range, center);
                for (int j = 0; j < subList.size(); j++) {
                    Point2D.Double p = subList.get(j);
                    if (!haveCloseEnoughPoint(p, list)) {
                        list.add(p);
                        nextPoints.add(p);
                    }
                }
            }
            points = nextPoints.toArray(new Point2D.Double[nextPoints.size()]);
        } while (points.length > 0);

        return list;
    }

    private List<Point2D.Double> getPoints(double cx, double cy,
            double radius, Rectangle r,
            Point2D.Double center) {
        List<Point2D.Double> list = new ArrayList<Point2D.Double>();
        double minDist = center.distance(cx, cy);
        for (int i = 0; i < 6; i++) {
            double theta = i * Math.PI / 3;

            double x = cx + radius * Math.cos(theta);
            double y = cy + radius * Math.sin(theta);
            double distance = center.distance(x, y);
            if (r.contains(x, y) && distance > minDist) {
                list.add(new Point2D.Double(x, y));
            }
        }
        return list;
    }

    private boolean haveCloseEnoughPoint(Point2D.Double p,
            List<Point2D.Double> list) {


        for (int i = 0; i < list.size(); i++) {
            Point2D.Double next = list.get(i);
            if (next.distance(p) < MIN_DIST) {
                return true;
            }
        }
        return false;
    }

    private Path2D.Double getPath(double cx, double cy, double R) {
        Path2D.Double path = new Path2D.Double();
        double thetaInc = 2 * Math.PI / 6;
        double theta = true ? -Math.PI / 2 : thetaInc;
        double x = cx + R * Math.cos(theta);
        double y = cy + R * Math.sin(theta);
        path.moveTo(x, y);
        for (int i = 0; i < 6; i++) {
            theta += thetaInc;
            x = cx + R * Math.cos(theta);
            y = cy + R * Math.sin(theta);
            path.lineTo(x, y);
        }
        return path;
    }

    public Posicao getCellByPoint(Point p) {

        double cx = getWidth() / 2.0;
        double cy = getHeight() / 2.0;
        double x = cx + (p.x - cx) / scale;
        double y = cy + (p.y - cy) / scale;
        p.setLocation((int) x, (int) y);

        for (int i = 0; i < posicoes.length; i++) {
            if (posicoes[i].contains(p)) {
                return posicoes[i];
            }
        }

        return null;
    }
    
    Posicao selecionado = null;
    ArrayList<Posicao> listSelecionados = new ArrayList<Posicao>();
    private MouseListener switcher = new MouseAdapter() {

        public void mousePressed(MouseEvent e) {

            Point p = e.getPoint();
            selecionado = getCellByPoint(p);

            boolean conectado = app.isConectado();
            boolean andamento = app.isPartidaIniciada();
            

            
            
            if(conectado && andamento) {
                     
                boolean jogDaVez = app.getJogadorLocal().isJogadorDaVez();
                
                if(jogDaVez) {
                
                    if (e.getButton() == 1) {             
                        selecionarPosicao();
                    } else {

                    boolean lance = app.procederLance(selecionado, listSelecionados);
                    
                    resetSelecionados(listSelecionados); 
                    
                    if (lance) {                         
                        app.avaliarVencedor();   
                        JogadaAbalone ja = new JogadaAbalone(app.getJogadorLocal(), posicoes);
                        atorRede.enviarJogada(ja);
                        verificaVencedor();
                    } 
                          
                        repaint();
                }
               
            } else {
                JOptionPane.showMessageDialog(null, "Espere sua vez");
            }
            }    
        }
    };
    
    public void selecionarPosicao() {

        boolean selecionadoOcupado = selecionado.isOcupado();
        int tamanhoLista = listSelecionados.size();

        if (selecionado.getJogador() != null) {

            if (selecionado.getJogador().getNome().equals(app.getJogadorLocal().getNome())) {

                if (tamanhoLista < 3 && selecionadoOcupado) {

                    selecionado.setSelecionado(true);
                    rePaint();

                    //Para o primeiro Selecionado
                    if (listSelecionados.isEmpty()) {
                        adiciona();
                    } else {
                        //Para o segundo selecionado, testa se é vizinho do segundo selecionado
                        if (listSelecionados.size() == 1) {
                            boolean vizinho = tabuleiro.isVizinho(selecionado.getVizinhos(), listSelecionados.get(0).getId());
                            if (vizinho) {
                                listSelecionados.add(selecionado);
                            } else {
                                resetSelecionados(listSelecionados);
                                adiciona();
                            }
                        } else {
                            //Para o terceiro selecionado, testa se são vizinhos e estão na mesma linha ou colunas
                            if (listSelecionados.size() == 2) {
                                boolean podeTerceiro = tabuleiro.verificarTerceiro(listSelecionados, selecionado);
                                if (podeTerceiro) {
                                    adiciona();
                                } else {
                                    resetSelecionados(listSelecionados);
                                    adiciona();
                                }
                            }
                        }
                    }
                } else {
                    if (selecionadoOcupado && tamanhoLista == 3) {
                        resetSelecionados(listSelecionados);
                        selecionado.setSelecionado(true);
                        rePaint();
                        adiciona();
                    }
                }

            }
        }
    }
    
        
   public void resetSelecionados(ArrayList<Posicao> selecionados){
       for(int i=0;  i < selecionados.size(); i++ ){
           selecionados.get(i).setSelecionado(false);
       }    
             selecionados.clear();
             rePaint();  
   }     

   public void adiciona(){    
        listSelecionados.add(selecionado);   
   }
   
   
    public void verificaVencedor() {
        if (app.getJogadorLocal().isVencedor()) {
            JOptionPane.showMessageDialog(null, "Vencedor: " + app.getJogadorLocal().getNome());
                resetTabuleiro();
        
        } else {
            if (app.getJogadorAdvesario().isVencedor()) {
                JOptionPane.showMessageDialog(null, "Vencedor: " + app.getJogadorAdvesario().getNome());
                resetTabuleiro();
            }
        }
    }

    public Posicao[] buildPosicoes() {
        return posicoes;
    }

    public AppAbalone getApp() {
        return app;
    }

    public void setApp(AppAbalone app) {
        this.app = app;
    }

    public Posicao[] getPosicoes() {
        return posicoes;
    }

    public void setPosicoes(Posicao[] posicoes) {
        this.posicoes = posicoes;
    }

    public Tabuleiro getTabuleiro() {
        return tabuleiro;
    }

    public void rePaint() {
        repaint();
    }

    public boolean isPartidaIniciada() {
        return partidaIniciada;
    }

    public void setPartidaIniciada(boolean partidaIniciada) {
        this.partidaIniciada = partidaIniciada;
    }

    public boolean isPrimeiroAJogar() {
        return primeiroAJogar;
    }

    public void setPrimeiroAJogar(boolean primeiroAJogar) {
        this.primeiroAJogar = primeiroAJogar;
    }
   
    public void resetTabuleiro(){
        app.getJogadorLocal().setTipoDaPeca("");
        app.getJogadorAdvesario().setTipoDaPeca("");
        primeiraVez = true;
        partidaIniciada = true;
        repaint();
    }
    
}
