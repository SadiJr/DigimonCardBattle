package view;

import controller.AppAbalone;
import javax.swing.JOptionPane;
import model.Mensagem;
import rede.AtorRede;

public class MessagePanel extends javax.swing.JPanel {
    
    AtorRede atorRede;
    boolean partidaIniciada ;
    AppAbalone app;

    
    MessagePanel(AtorRede _atorRede, AppAbalone _app){
        initComponents();
        atorRede = _atorRede;
        app = _app;
        partidaIniciada = false;
    }
    
    public void clearAllFields(){
        messageTextArea.setText("");
        messageTextField.setText("");
    }
    
            
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jScrollPane1 = new javax.swing.JScrollPane();
        messageTextArea = new javax.swing.JTextArea();
        messageTextField = new javax.swing.JTextField();
        sendMessageButton = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Mensagens", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 204, 51))); // NOI18N
        setLayout(new java.awt.GridBagLayout());

        messageTextArea.setColumns(20);
        messageTextArea.setRows(5);
        jScrollPane1.setViewportView(messageTextArea);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.ipadx = 377;
        gridBagConstraints.insets = new java.awt.Insets(6, 7, 5, 12);
        add(jScrollPane1, gridBagConstraints);

        messageTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                messageTextFieldKeyPressed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 454;
        gridBagConstraints.ipady = 8;
        gridBagConstraints.insets = new java.awt.Insets(0, 7, 0, 7);
        add(messageTextField, gridBagConstraints);

        sendMessageButton.setText("enviar");
        sendMessageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendMessageButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        add(sendMessageButton, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

private void sendMessageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendMessageButtonActionPerformed
       enviarMensagem();             
}//GEN-LAST:event_sendMessageButtonActionPerformed

private void messageTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_messageTextFieldKeyPressed

}//GEN-LAST:event_messageTextFieldKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea messageTextArea;
    private javax.swing.JTextField messageTextField;
    private javax.swing.JButton sendMessageButton;
    // End of variables declaration//GEN-END:variables


    public void receberMensagemRede(String mensagem) {
        String texto = editTexto(mensagem);
        messageTextArea.setText(texto);
    }
    
    
    public String editTexto(String mensagem){
        String texto = messageTextArea.getText();
        texto = texto +"\n" + mensagem;   
        return texto; 
    }
    
    public void enviarMensagem(){
        
        boolean conectado = app.isConectado();
        
        if(conectado){
            
            boolean iniciada = app.isPartidaIniciada();
            
            if(iniciada){            
                String msg = getTexto();
                Mensagem env = atorRede.enviarJogada(msg);
                
                if(env != null) {
                    msg = env.getMensagem();
                    atualizarViewMsg(msg);
                } else{
                   JOptionPane.showMessageDialog(null, "Mensagem não enviada" ); 
                }
            } else{
              JOptionPane.showMessageDialog(null, "Jogo não iniciado" );  
            }
        } else {
            JOptionPane.showMessageDialog(null, "Não conectado");
        }
    }

    private String getTexto() {
        return messageTextField.getText();
    }

    private void atualizarViewMsg(String msg) {
        receberMensagemRede(msg);
        messageTextField.setText("");
    }
    
    
}
