package view;

import controller.AppAbalone;
import javax.swing.JOptionPane;
import rede.AtorRede;


public class MenuPanel extends javax.swing.JPanel {

    private AppAbalone app;
    private AtorRede atorRede;
    
    public MenuPanel(AtorRede _atorRede, AppAbalone app) {
        initComponents();
        atorRede = _atorRede;
        this.app = app;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        bntIniciar = new javax.swing.JButton();
        btnOpcoes = new javax.swing.JButton();
        bntCarregar = new javax.swing.JButton();
        btnDesconectar = new javax.swing.JButton();
        btnAjuda = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 153, 51)), "Menu", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 255, 51))); // NOI18N
        setLayout(new java.awt.GridBagLayout());

        bntIniciar.setText("Iniciar");
        bntIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntIniciarActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 20;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 8, 3, 4);
        add(bntIniciar, gridBagConstraints);

        btnOpcoes.setText("Conectar");
        btnOpcoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOpcoesActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 10, 0, 10);
        add(btnOpcoes, gridBagConstraints);

        bntCarregar.setText("Carregar");
        bntCarregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntCarregarActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 10, 0, 10);
        add(bntCarregar, gridBagConstraints);

        btnDesconectar.setText("Encerrar");
        btnDesconectar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDesconectarActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.ipadx = 7;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 8, 5, 5);
        add(btnDesconectar, gridBagConstraints);

        btnAjuda.setText("Ajuda");
        btnAjuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAjudaActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.ipadx = 16;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 10, 0, 10);
        add(btnAjuda, gridBagConstraints);

        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.ipadx = 14;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 8, 3, 8);
        add(btnSalvar, gridBagConstraints);

        btnSair.setText("Sair");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.ipadx = 26;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 9, 3, 5);
        add(btnSair, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

private void bntIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntIniciarActionPerformed
    
    iniciarPartida();
    
}//GEN-LAST:event_bntIniciarActionPerformed

private void btnOpcoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOpcoesActionPerformed
   
    if(!app.isConectado()){
        solicitaDados();
    } else {
        JOptionPane.showMessageDialog(null, "Já conectado");
    }
    
}//GEN-LAST:event_btnOpcoesActionPerformed

private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
    SalvarView salvar = new SalvarView(app);
}//GEN-LAST:event_btnSalvarActionPerformed

private void bntCarregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntCarregarActionPerformed
    CarregarView carregar = new CarregarView(app);
}//GEN-LAST:event_bntCarregarActionPerformed

private void btnDesconectarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDesconectarActionPerformed
    desconectar();
}//GEN-LAST:event_btnDesconectarActionPerformed

private void btnAjudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAjudaActionPerformed
    new AjudaView();
}//GEN-LAST:event_btnAjudaActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bntCarregar;
    private javax.swing.JButton bntIniciar;
    private javax.swing.JButton btnAjuda;
    private javax.swing.JButton btnDesconectar;
    private javax.swing.JButton btnOpcoes;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalvar;
    // End of variables declaration//GEN-END:variables

    public void solicitaDados() {
        new ConexaoView(atorRede, app);
    }

    public void desconectar() {
        
        boolean conectado = app.isConectado();
        
        if (conectado) {
            
            boolean iniciada = app.isPartidaIniciada();
            
            if(iniciada){
                registrarPartidaInterrompida();
            }
                
            registrarDesconectado(); 
            resetTabuleiro();
                  
        } else {
            JOptionPane.showMessageDialog(null, "Não conectado");
        }
    }

    private void registrarDesconectado() {
        atorRede.desconectar();
        app.appDesconectar();
    }

    private void resetTabuleiro() {
        atorRede.getAbaloneView().getTabuleiroView().resetTabuleiro();
    }

    private void registrarPartidaInterrompida() {
        atorRede.encerrarPartida();
        app.appEncerrarPartida();
    }

    private void iniciarPartida() {
        boolean conectado = app.isConectado();
        
        if (conectado) {
            
            boolean iniciada = app.isPartidaIniciada();
            
            if(!iniciada){
                atorRede.iniciarPartida();
            } else{
                JOptionPane.showMessageDialog(null, "Partida já iniciada");
            }
                             
        } else {
            JOptionPane.showMessageDialog(null, "Não conectado");
        }
    }
    
    
}
