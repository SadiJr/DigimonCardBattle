/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import br.ufsc.inf.leobr.cliente.Jogada;
import java.util.ArrayList;

/**
 *
 * @author Milton Bittencourt
 */
public class Jogador implements Jogada {
    
   protected String nome;
   protected boolean jogadorDaVez;
   protected String tipoDaPeca;
   protected boolean vencedor;
   protected int qtPecas;
   protected ArrayList<Mensagem> listaMensagens;

    public Jogador(String nome, boolean jogadorDaVez, String tipoDaPeao, boolean vencedor, int qtPecas) {
        this.nome = nome;
        this.jogadorDaVez = jogadorDaVez;
        this.tipoDaPeca = tipoDaPeca;
        this.vencedor = vencedor;
        this.qtPecas = qtPecas;
    }

    public Jogador() {
        
    }

    public boolean isJogadorDaVez() {
        return jogadorDaVez;
    }

    public void setJogadorDaVez(boolean jogadorDaVez) {
        this.jogadorDaVez = jogadorDaVez;
    }

    public ArrayList<Mensagem> getListaMensagens() {
        return listaMensagens;
    }

    public void setListaMensagens(ArrayList<Mensagem> listaMensagens) {
        this.listaMensagens = listaMensagens;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }



    /**
	 * @return the tipoDaPeca
	 */
	public String getTipoDaPeca() {
		return tipoDaPeca;
	}

	/**
	 * @param tipoDaPeca the tipoDaPeca to set
	 */
	public void setTipoDaPeca(String tipoDaPeca) {
		this.tipoDaPeca = tipoDaPeca;
	}

	/**
	 * @return the qtPecas
	 */
	public int getQtPecas() {
		return qtPecas;
	}

	/**
	 * @param qtPecas the qtPecas to set
	 */
	public void setQtPecas(int qtPecas) {
		this.qtPecas = qtPecas;
	}

	public boolean isVencedor() {
        return vencedor;
    }

    public void setVencedor(boolean vencedor) {
        this.vencedor = vencedor;
    }
   
}