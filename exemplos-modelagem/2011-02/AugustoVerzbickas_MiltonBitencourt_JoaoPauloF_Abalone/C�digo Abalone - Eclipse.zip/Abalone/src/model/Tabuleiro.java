/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import br.ufsc.inf.leobr.cliente.Jogada;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import util.AbaloneUtil;

/**
 * @author Milton Bittencourt
 */
public class Tabuleiro implements Jogada {
 
    Posicao[] posicoes;
    ArrayList<String> posProibidas;
    AbaloneUtil abaloneUtil;

    public Tabuleiro(AbaloneUtil abaloneUtil) {
        this.abaloneUtil = abaloneUtil;
        posicoes = abaloneUtil.buildPosicoes();
        posProibidas = abaloneUtil.getProibidas();
    }
    
    public AbaloneUtil getAbaloneUtil() {
        return abaloneUtil;
    }

    public void setAbaloneUtil(AbaloneUtil abaloneUtil) {
        this.abaloneUtil = abaloneUtil;
    }

    public ArrayList<String> getPosProibidas() {
        return posProibidas;
    }

    public void setPosProibidas(ArrayList<String> posProibidas) {
        this.posProibidas = posProibidas;
    }
    
    

    public Posicao getNaoVizinha(Posicao sel1, Posicao sel2, Posicao destino) {

        String[] vizinhos1 = sel1.getVizinhos();
        String[] vizinhos2 = sel2.getVizinhos();

        boolean sel1Vizinha = isVizinho(vizinhos1, destino.getId());
        boolean sel2Vizinha = isVizinho(vizinhos2, destino.getId());

        if (sel1Vizinha) {
            return sel2;
        } else {
            if (sel2Vizinha) {
                return sel1;
            }
        }

        return null;
    }

    public boolean isVizinho(String[] vizinhos, String id) {
        
        posicoes = abaloneUtil.buildPosicoes();
        
        List<String> vizi = Arrays.asList(vizinhos);

        if (vizi.contains(id)) {
            return true;
        }

        return false;
    }

    public Posicao getCellById(String id) {

        for (int i = 0; i < posicoes.length; i++) {
            if (posicoes[i].getId().equals(id)) {
                return posicoes[i];
            }
        }
        return null;
    }

    public boolean verificarTerceiro(ArrayList<Posicao> listaS, Posicao sel) {
        Posicao um = listaS.get(0);
        Posicao dois = listaS.get(1);

        if (um.getLinha().equals(dois.getLinha()) && dois.getLinha().equals(sel.getLinha())) {
            return true;
        }

        if (um.getDiagonalDireita().equals(dois.getDiagonalDireita()) && dois.getDiagonalDireita().equals(sel.getDiagonalDireita())) {
            return true;
        }

        if (um.getDiagonalEsquerda().equals(dois.getDiagonalEsquerda()) && dois.getDiagonalEsquerda().equals(sel.getDiagonalEsquerda())) {
            return true;
        }

        return false;
    }

    public Posicao getMovida3(Posicao a, Posicao b, Posicao c, Posicao destino) {

        String[] vsA = a.getVizinhos();
        String[] vsB = b.getVizinhos();
        String[] vsC = c.getVizinhos();

        if (isVizinho(vsA, destino.getId()) && isVizinho(vsA, b.getId())) {
            return c;
        }

        if (isVizinho(vsB, destino.getId()) && isVizinho(vsB, a.getId())) {
            return c;
        }


        if (isVizinho(vsC, destino.getId()) && isVizinho(vsC, b.getId())) {
            return a;
        }

        if (isVizinho(vsB, destino.getId()) && isVizinho(vsB, c.getId())) {
            return a;
        }

        if (isVizinho(vsC, destino.getId()) && isVizinho(vsC, a.getId())) {
            return b;
        }

        if (isVizinho(vsA, destino.getId()) && isVizinho(vsA, c.getId())) {
            return b;
        }

        return null;
    }

    public Posicao getNewDestino(Posicao sel1, Posicao sel2, Posicao destino) {

        posicoes = abaloneUtil.buildPosicoes();

        Posicao newDestino;

        String[] vizinhod = destino.getVizinhos();

        for (int i = 0; i < vizinhod.length; i++) {
            newDestino = getCellById(vizinhod[i]);
            if (((newDestino.getLinha().equals(sel1.getLinha()) && newDestino.getLinha().equals(sel2.getLinha()))
                    || (newDestino.getDiagonalDireita().equals(sel1.getDiagonalDireita()) && newDestino.getDiagonalDireita().equals(sel2.getDiagonalDireita()))
                    || (newDestino.getDiagonalEsquerda().equals(sel1.getDiagonalEsquerda()) && newDestino.getDiagonalEsquerda().equals(sel2.getDiagonalEsquerda())))
                    && !(newDestino.getId().equals(sel1.getId())) && !(newDestino.getId().equals(sel2.getId()))) {
                return newDestino;
            }
        }

        return null;
    }

    public Posicao getNewDestino2(Posicao sel1, Posicao sel2, Posicao sel3, Posicao destino) {

        posicoes = abaloneUtil.buildPosicoes();

        Posicao newDestino;

        String[] vizinhod = destino.getVizinhos();

        for (int i = 0; i < vizinhod.length; i++) {
            newDestino = getCellById(vizinhod[i]);
            if (((newDestino.getLinha().equals(sel1.getLinha()) && newDestino.getLinha().equals(sel2.getLinha()))
                    || (newDestino.getDiagonalDireita().equals(sel1.getDiagonalDireita())
                    && newDestino.getDiagonalDireita().equals(sel2.getDiagonalDireita()))
                    || (newDestino.getDiagonalEsquerda().equals(sel1.getDiagonalEsquerda())
                    && newDestino.getDiagonalEsquerda().equals(sel2.getDiagonalEsquerda())))
                    && !(newDestino.getId().equals(sel1.getId()))
                    && !(newDestino.getId().equals(sel2.getId()))
                    && !(newDestino.getId().equals(sel3.getId())) && !(newDestino.getId().equals(destino.getId()))) {

                return newDestino;

            }
        }

        return null;
    }

    public Posicao getNewDestino3(Posicao sel1, Posicao sel2, Posicao sel3, Posicao destino) {

        posicoes = abaloneUtil.buildPosicoes();

        Posicao newDestino;

        String[] vizinhod = destino.getVizinhos();

        for (int i = 0; i < vizinhod.length; i++) {
            newDestino = getCellById(vizinhod[i]);
            if (((newDestino.getLinha().equals(sel1.getLinha()) && newDestino.getLinha().equals(sel2.getLinha()))
                    || (newDestino.getDiagonalDireita().equals(sel1.getDiagonalDireita())
                    && newDestino.getDiagonalDireita().equals(sel2.getDiagonalDireita())) || (newDestino.getDiagonalEsquerda().equals(sel1.getDiagonalEsquerda())
                    && newDestino.getDiagonalEsquerda().equals(sel2.getDiagonalEsquerda()))) && !(newDestino.getId().equals(sel1.getId()))
                    && !(newDestino.getId().equals(sel2.getId())) && !(newDestino.getId().equals(sel3.getId()))
                    && !(newDestino.getId().equals(destino.getId()))) {
                if (!newDestino.isOcupado() || isProibida(newDestino)) {
                    return newDestino;
                }
            }
        }

        return null;
    }

    public boolean isProibida(Posicao hexCell) {
        if (posProibidas.contains(hexCell.getId())) {
            return true;
        }
        return false;
    }

    public Posicao[] getPosicoes() {
        return posicoes;
    }

    public void setPosicoes(Posicao[] posicoes) {
        this.posicoes = posicoes;
    }
    
    
}
