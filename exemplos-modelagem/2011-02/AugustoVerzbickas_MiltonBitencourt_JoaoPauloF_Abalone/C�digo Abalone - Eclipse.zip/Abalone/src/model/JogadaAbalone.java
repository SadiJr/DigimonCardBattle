
package model;

import br.ufsc.inf.leobr.cliente.Jogada;

public class JogadaAbalone implements Jogada {
    
    protected Jogador jogador;
    protected Posicao[] Posicoes;

    public JogadaAbalone(Jogador jogador, Posicao[] Posicoes) {
        this.jogador = jogador;
        this.Posicoes = Posicoes;
    }

    public Posicao[] getPosicoes() {
        return Posicoes;
    }

    public void setPosicoes(Posicao[] Posicoes) {
        this.Posicoes = Posicoes;
    }

    public Jogador getJogador() {
        return jogador;
    }

    public void setJogador(Jogador jogador) {
        this.jogador = jogador;
    }
   
}
