package model;

import br.ufsc.inf.leobr.cliente.Jogada;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.Point2D;
import java.util.Arrays;
import javax.swing.ImageIcon;

public class Posicao implements Jogada {

    //parte lógica
    protected Jogador jogador;
    protected String nomeJogador = "";
    protected String id;
    protected String linha;
    protected String diagonalEsquerda;
    protected String diagonalDireita;
    protected String[] vizinhos;
    protected boolean ocupado = false;
    protected boolean selecionado = false;
    //parte gráfica
    protected Point2D.Double center;
    protected Shape shape;
    protected double start;
    Color colorSelecionado = Color.RED;
    
 
    
    public Posicao(String id, Point2D.Double center, Shape shape, double start, String[] vizinhos) {
        this.id = id;
        this.center = center;
        this.shape = shape;
        this.start = start;
        this.vizinhos = vizinhos;
    }

    public String getDiagonalDireita() {
        return diagonalDireita;
    }

    public void setDiagonalDireita(String diagonalDireita) {
        this.diagonalDireita = diagonalDireita;
    }

    public String getDiagonalEsquerda() {
        return diagonalEsquerda;
    }

    public void setDiagonalEsquerda(String diagonalEsquerda) {
        this.diagonalEsquerda = diagonalEsquerda;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setIsBusy(boolean isBusy) {
        this.ocupado = isBusy;
    }

    public String getLinha() {
        return linha;
    }

    public void setLinha(String linha) {
        this.linha = linha;
    }

    public String[] getVizinhos() {
        return vizinhos;
    }

    public void setVizinhos(String[] vizinhos) {
        this.vizinhos = vizinhos;
    }

    public Jogador getJogador() {
        return jogador;
    }

    public void setJogador(Jogador jogador) {
        this.jogador = jogador;
    }
      
    public boolean isOcupado() {
        return ocupado;
    }

    public void setOcupado(boolean ocupado) {
        this.ocupado = ocupado;
    }

    public boolean isSelecionado() {
        return selecionado;
    }

    public void setSelecionado(boolean selecionado) {
        this.selecionado = selecionado;
    }
    
    
    
    public void draw(Graphics2D g2) {
        
        if(selecionado){
        g2.setPaint(colorSelecionado);
        } else{
          g2.setPaint(Color.lightGray);  
        }
        
        g2.draw(shape);
        if (ocupado && jogador != null) {
            
            printIcon(g2, jogador.tipoDaPeça);
           
        }
    }
    
    public boolean contains(Point p) {
        return shape.contains(p);
    }

    public void printIcon(Graphics2D g2, String urlImage) {
        Font font = g2.getFont();
        FontRenderContext frc = g2.getFontRenderContext();
        LineMetrics lm = font.getLineMetrics("0", frc);
        float sh = lm.getAscent() + lm.getDescent();
        Rectangle r = shape.getBounds();
        int R = Math.max(r.width, r.height) / 2;
        double thetaInc = 2 * Math.PI / 6;
        double theta = start;
        double lastX = 0, lastY = 0;
        for (int i = 0; i <= vizinhos.length; i++) {
            double x = center.x + R * Math.cos(theta);
            double y = center.y + R * Math.sin(theta);
            if (i > 0 && vizinhos[i - 1] != null) {
                float midx = (float) (x - (x - lastX) / 2);
                float midy = (float) (y - (y - lastY) / 2);
                double phi = Math.atan2(midy - center.y, midx - center.x);
                String s = vizinhos[i - 1];
                double sw = font.getStringBounds(s, frc).getWidth();
                double diag = Math.sqrt(sw * sw + sh * sh) / 2;
                float sx = (float) (midx - diag * Math.cos(phi) - sw / 2);
                float sy = (float) (midy - diag * Math.sin(phi)) + lm.getDescent();

                Image xd = new ImageIcon(getClass().getResource(urlImage)).getImage();

                if (i == 5) {
                    g2.drawImage(xd, (int) (sx - 6), (int) (sy - 6), null);
                }
            }
            lastX = x;
            lastY = y;
            theta += thetaInc;
        }
    }

    public String toString() {
        return "Posição[id:" + id + ", vizinhos:"
                + Arrays.toString(vizinhos) + " busy: " + ocupado + "]";
    }
}