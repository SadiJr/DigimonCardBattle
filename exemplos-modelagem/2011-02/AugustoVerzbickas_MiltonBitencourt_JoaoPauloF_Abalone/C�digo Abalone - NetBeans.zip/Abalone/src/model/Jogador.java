/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import br.ufsc.inf.leobr.cliente.Jogada;
import java.util.ArrayList;

/**
 *
 * @author Milton Bittencourt
 */
public class Jogador implements Jogada {
    
   protected String nome;
   protected boolean jogadorDaVez;
   protected String tipoDaPeça;
   protected boolean vencedor;
   protected int qtPeças;
   protected ArrayList<Mensagem> listaMensagens;

    public Jogador(String nome, boolean jogadorDaVez, String tipoDaPeça, boolean vencedor, int qtPeças) {
        this.nome = nome;
        this.jogadorDaVez = jogadorDaVez;
        this.tipoDaPeça = tipoDaPeça;
        this.vencedor = vencedor;
        this.qtPeças = qtPeças;
    }

    public Jogador() {
        
    }

    public boolean isJogadorDaVez() {
        return jogadorDaVez;
    }

    public void setJogadorDaVez(boolean jogadorDaVez) {
        this.jogadorDaVez = jogadorDaVez;
    }

    public ArrayList<Mensagem> getListaMensagens() {
        return listaMensagens;
    }

    public void setListaMensagens(ArrayList<Mensagem> listaMensagens) {
        this.listaMensagens = listaMensagens;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQtPeças() {
        return qtPeças;
    }

    public void setQtPeças(int qtPeças) {
        this.qtPeças = qtPeças;
    }

    public String getTipoDaPeça() {
        return tipoDaPeça;
    }

    public void setTipoDaPeça(String tipoDaPeça) {
        this.tipoDaPeça = tipoDaPeça;
    }

    public boolean isVencedor() {
        return vencedor;
    }

    public void setVencedor(boolean vencedor) {
        this.vencedor = vencedor;
    }
   
}