/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import br.ufsc.inf.leobr.cliente.Jogada;

/**
 * @author Milton Bittencourt
 */
public class Mensagem implements Jogada {
    
    protected String mensagem;
    protected Jogador emissor;

    public Mensagem(String mensagem, Jogador emissor) {
        this.mensagem = mensagem;
        this.emissor = emissor;
    }

    public Jogador getEmissor() {
        return emissor;
    }

    public void setEmissor(Jogador emissor) {
        this.emissor = emissor;
    }
        
    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
    
}
