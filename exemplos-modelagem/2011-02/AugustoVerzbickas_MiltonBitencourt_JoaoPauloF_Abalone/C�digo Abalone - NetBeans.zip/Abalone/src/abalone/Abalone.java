/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abalone;

import controller.AppAbalone;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import view.AbaloneView;

public class Abalone {


    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
        AppAbalone app = new AppAbalone();
        AbaloneView abaloneView = new AbaloneView(app);
        abaloneView.setSize (700, 700);
        abaloneView.setLocationRelativeTo(null);
        abaloneView.show();
  //      UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
    }
}
