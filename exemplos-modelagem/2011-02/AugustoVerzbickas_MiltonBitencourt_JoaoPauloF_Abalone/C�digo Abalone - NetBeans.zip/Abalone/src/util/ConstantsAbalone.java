/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Milton Bittencourt
 */
public class ConstantsAbalone {
    
    //Contants de icones
    public final static String CAVEIRA = "/abalone/image/caveira.png";
    public final static String ALIEN = "/abalone/image/alien_32.png";
    public final static String PANDA = "/abalone/image/Panda.png";
    public final static String OBAMA = "/abalone/image/Barak-Obama-32.png";
    public final static String SOLDADO = "/abalone/image/GasSoldier.png";
}
