/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import model.Posicao;


/**
 *
 * @author Augusto Costa
 */
public class ControlePersistencia {
    
    private AppAbalone app;
    
    private final File dir = new File("Jogos Salvos");
    
    public ControlePersistencia(AppAbalone app){
        this.app = app;
    }
    
    public void salvar(String nomeArquivo) throws FileNotFoundException, IOException{
        File arquivo = new File(dir, nomeArquivo);
        FileOutputStream fos = new FileOutputStream(arquivo);
        ObjectOutputStream escritor = new ObjectOutputStream(fos);
        
        escritor.writeObject(app.getTabuleiro().getPosicoes());
        
        fos.close();
        escritor.close();
    }   
    
    public Posicao[] carregar(String nomeArquivo) throws FileNotFoundException, IOException, ClassNotFoundException{
        File arquivo = new File(dir, nomeArquivo);
        FileInputStream fis = new FileInputStream(arquivo);
        ObjectInputStream leitor = new ObjectInputStream(fis);
        
        Posicao[] pos = (Posicao[]) leitor.readObject();
        
        fis.close();
        leitor.close();
        
        return pos;
    }
}
