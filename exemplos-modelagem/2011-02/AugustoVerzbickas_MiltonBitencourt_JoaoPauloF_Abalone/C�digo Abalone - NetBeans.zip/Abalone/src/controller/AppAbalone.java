package controller;

import br.ufsc.inf.leobr.cliente.Jogada;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import model.Jogador;
import model.Posicao;
import model.Tabuleiro;


public class AppAbalone implements Jogada {

    protected Tabuleiro tabuleiro;
    protected Jogador jogadorLocal;
    protected Jogador jogadorAdvesario;
    protected boolean conectado;
    protected boolean partidaIniciada;

    public Tabuleiro getTabuleiro() {
        return tabuleiro;
    }

    public void setTabuleiro(Tabuleiro tabuleiro) {
        this.tabuleiro = tabuleiro;
    }

    public Jogador getJogadorAdvesario() {
        return jogadorAdvesario;
    }

    public void setJogadorAdvesario(Jogador jogadorAdvesario) {
        this.jogadorAdvesario = jogadorAdvesario;
    }

    public Jogador getJogadorLocal() {
        return jogadorLocal;
    }

    public void setJogadorLocal(Jogador jogadorLocal) {
        this.jogadorLocal = jogadorLocal;
    }

    public void salvar(String nomeArquivo) throws FileNotFoundException, IOException {
        ControlePersistencia cp = new ControlePersistencia(this);
        String nomeAtualizado = nomeArquivo;
        int i = 1;
        while (this.listarJogosSalvos().contains(nomeAtualizado)) {
            nomeAtualizado = nomeArquivo + "(" + i + ")";
            i++;
        }
        cp.salvar(nomeAtualizado);
    }
    
    public void carregar(String nomeArquivo) throws FileNotFoundException, IOException, ClassNotFoundException{
        ControlePersistencia cp = new ControlePersistencia(this);
        Posicao[] posicoes = cp.carregar(nomeArquivo);
        tabuleiro.setPosicoes(posicoes);
        tabuleiro.getAbaloneUtil().getTv().rePaint();
    }

    public DefaultListModel listarJogosSalvos() {
        File dir = new File("Jogos Salvos");
        String[] jogosSalvos = dir.list();
        DefaultListModel listModel = new DefaultListModel();
        for (String jogo : jogosSalvos) {
            if (jogo.contains(".asg")) {
                listModel.addElement(jogo);
            }
        }
        return listModel;
    }

    public boolean procederLance(Posicao destino, ArrayList<Posicao> listSelecionados) {

        if (!listSelecionados.isEmpty()) {  

            if (listSelecionados.size() == 1) {
                Posicao sel1 = listSelecionados.get(0);
                String[] vizinhos1 = sel1.getVizinhos();
                boolean isVizinho = tabuleiro.isVizinho(vizinhos1, destino.getId());
                //mover uma
                if (!destino.isOcupado() && isVizinho) {

                    destino.setOcupado(true);
                    destino.setJogador(sel1.getJogador());
                    sel1.setOcupado(false);
                    sel1.setJogador(null);
                    return true;

                } else {
                    return false;
                }           
            }

            if (listSelecionados.size() == 2) {

                Posicao sel1 = listSelecionados.get(0);
                Posicao sel2 = listSelecionados.get(1);

                boolean isVizinho = tabuleiro.verificarTerceiro(listSelecionados, destino);

                //mover duas
                if (!destino.isOcupado() && isVizinho) {

                    Posicao newCellOcupada = tabuleiro.getNaoVizinha(sel1, sel2, destino);
                    if (newCellOcupada != null) {
                        destino.setOcupado(true);
                        destino.setJogador(sel1.getJogador());
                        newCellOcupada.setOcupado(false);
                        newCellOcupada.setJogador(null);
                        return true;
                    } else {
                        return false;
                    }


                } else {
                    //combate 2x1
                    if ((destino.isOcupado() && isVizinho)) {

                        if (!tabuleiro.isProibida(destino)) {

                            Posicao newDestino = tabuleiro.getNewDestino(sel1, sel2, destino);

                            if (tabuleiro.isProibida(newDestino)) {
                                System.out.println("Posição proibida 2x1");
                                Posicao newCellOcupada = tabuleiro.getNaoVizinha(sel1, sel2, destino);
                                //descontar ponto aqui
                                destino.setOcupado(true);
                                destino.setJogador(sel1.getJogador());
                                newCellOcupada.setOcupado(false);
                                newCellOcupada.setJogador(null);
                                return true;
                            } else {

                                if (newDestino != null) {
                                    Posicao newCellOcupada = tabuleiro.getNaoVizinha(sel1, sel2, destino);
                                    if (newCellOcupada != null && !newDestino.isOcupado()) {
                                        newDestino.setJogador(destino.getJogador());
                                        newDestino.setOcupado(true);
                                        destino.setOcupado(true);
                                        destino.setJogador(sel1.getJogador());
                                        newCellOcupada.setOcupado(false);
                                        newCellOcupada.setJogador(null);
                                        return true;
                                    } else {
                                        return false;
                                    }
                                } else {
                                    return false;
                                }
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }

                }
                
            }

            if (listSelecionados.size() == 3) {

                System.out.println("tratar tres selecionados");

                Posicao sel1 = listSelecionados.get(0);
                Posicao sel2 = listSelecionados.get(1);
                Posicao sel3 = listSelecionados.get(2);

                boolean coordenadaValida = tabuleiro.verificarTerceiro(listSelecionados, destino);

                Posicao movida = tabuleiro.getMovida3(sel1, sel2, sel3, destino);
                
                //apenas mover 3
                if (coordenadaValida && !destino.isOcupado() && movida != null) {

                    destino.setOcupado(true);
                    destino.setJogador(sel1.getJogador());
                    movida.setOcupado(false);
                    movida.setJogador(null);
                    return true;

                } else {
                    if (coordenadaValida && destino.isOcupado() && movida != null) {

                        
                        if (!tabuleiro.isProibida(destino)) {
                            Posicao newDestino = tabuleiro.getNewDestino2(sel1, sel2, sel3, destino);
                            //combate 3x1 empurrando para fora do tab
                            if (tabuleiro.isProibida(newDestino)) {
                                //tratar descontar ponto
                                System.out.println("Posição Proibida 3x1");
                                destino.setOcupado(true);
                                destino.setJogador(sel1.getJogador());
                                movida.setOcupado(false);
                                movida.setJogador(null);
                                return true;

                            } else {
                                //combate 3x1 sem empurrar para fora do tab
                                if (newDestino != null && !newDestino.isOcupado()) {
                                    newDestino.setOcupado(true);
                                    newDestino.setJogador(destino.getJogador());
                                    destino.setOcupado(true);
                                    destino.setJogador(sel1.getJogador());
                                    movida.setOcupado(false);
                                    movida.setJogador(null);
                                    return true;
                                    
                                } else {
                                    //combate 3x2
                                    if (newDestino != null && newDestino.isOcupado()) {

                                        Posicao newDestino2 = tabuleiro.getNewDestino3(sel1, sel2, sel3, newDestino);

                                        System.out.println("Posição Proibida:" + newDestino2.getId());
                                        if (tabuleiro.isProibida(newDestino2)) {
                                            // tratar descontar pontos

                                            System.out.println("Posição Proibida 3x2");
                                            newDestino.setOcupado(true);
                                            newDestino.setJogador(destino.getJogador());
                                            destino.setOcupado(true);
                                            destino.setJogador(sel1.getJogador());
                                            movida.setOcupado(false);
                                            movida.setJogador(null);
                                            return true;

                                        } else {

                                            if (newDestino2 != null && !newDestino2.isOcupado()) {
                                                newDestino2.setOcupado(true);
                                                newDestino2.setJogador(destino.getJogador());
                                                newDestino.setOcupado(true);
                                                newDestino.setJogador(destino.getJogador());
                                                destino.setOcupado(true);
                                                destino.setJogador(sel1.getJogador());
                                                movida.setOcupado(false);
                                                movida.setJogador(null);
                                                return true;
                                            }
                                        }
                                    }
                                }
                            }
                        } 
                    }
                }
            }

        }

        return false;
    }

    public Jogador avaliarVencedor() {
        Posicao[] pos = tabuleiro.getPosicoes();
        int qtLocal = 0;
        int qtAdv = 0;

        for (int i = 0; i < pos.length; i++) {
            Posicao p = pos[i];
            if (p.isOcupado()) {
                
                if(p.getJogador() != null){
                    
                if(p.getJogador().getNome() != null){
                    
                
                                
                if (p.getJogador().getNome().equals(jogadorLocal.getNome())) {
                    qtLocal++;
                }

                if (p.getJogador().getNome().equals(jogadorAdvesario.getNome())) {
                    qtAdv++;
                }
                }
                }
            }

        }

        if (qtLocal <= 13) {
            jogadorAdvesario.setVencedor(true);
            return jogadorAdvesario;
        } else {
            if (qtAdv <= 13) {
                jogadorLocal.setVencedor(true);
                return jogadorLocal;
            }
        }

        return null;
    }
    
    public void appConectar(){
        conectado = true;
    }
    
    public void appDesconectar(){
        conectado = false;
        
    }    
    
    public void appIniciarPartida(){
        partidaIniciada = true;
    }
    
    public void appEncerrarPartida(){
        partidaIniciada = false;
    }

    public boolean isConectado() {
        return conectado;
    }

    public boolean isPartidaIniciada() {
        return partidaIniciada;
    }
    
    
    
}
