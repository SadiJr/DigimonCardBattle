package rede;

import br.ufsc.inf.leobr.cliente.Jogada;
import br.ufsc.inf.leobr.cliente.OuvidorProxy;
import br.ufsc.inf.leobr.cliente.Proxy;
import br.ufsc.inf.leobr.cliente.exception.ArquivoMultiplayerException;
import br.ufsc.inf.leobr.cliente.exception.JahConectadoException;
import br.ufsc.inf.leobr.cliente.exception.NaoConectadoException;
import br.ufsc.inf.leobr.cliente.exception.NaoJogandoException;
import br.ufsc.inf.leobr.cliente.exception.NaoPossivelConectarException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.JogadaAbalone;
import model.Jogador;
import model.Mensagem;
import view.AbaloneView;


public class AtorRede implements OuvidorProxy, Jogada {
    
    AbaloneView abaloneView;
    Proxy proxy;        
    
    public AtorRede(AbaloneView av){ 
        abaloneView = av;
        proxy = Proxy.getInstance();        
    }
    
    public boolean iniciarPartida(){   
        try {
            proxy.iniciarPartida(2);
            return true;
        } catch (NaoConectadoException ex) {
            Logger.getLogger(AtorRede.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
   
    public boolean conectar(String nome, String ipServidor){
        try {
            proxy.addOuvinte(this);
            proxy.conectar(ipServidor, nome);
            return true;
        } catch (JahConectadoException ex) {
            Logger.getLogger(AtorRede.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } catch (NaoPossivelConectarException ex) {
            Logger.getLogger(AtorRede.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } catch (ArquivoMultiplayerException ex) {
            Logger.getLogger(AtorRede.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }          
    }    
   
    public Mensagem enviarJogada(String msg){
        
        Mensagem mensagem = new Mensagem(msg, abaloneView.getApp().getJogadorLocal());
        try {
            String msge = abaloneView.getApp().getJogadorLocal().getNome() + " diz: " + msg;
            mensagem.setMensagem(msge);
            proxy.enviaJogada(mensagem);
            return mensagem;
        } catch (NaoJogandoException ex) {
            Logger.getLogger(AtorRede.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }   
    
    public boolean enviarJogada(JogadaAbalone ja){
               
        try {
            proxy.enviaJogada(ja);
            abaloneView.getApp().getJogadorLocal().setJogadorDaVez(false);
            abaloneView.getTabuleiroView().rePaint();
            return true;
        } catch (NaoJogandoException ex) {
            System.out.print("ERRO?");
            Logger.getLogger(AtorRede.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
        
    public boolean enviarJogada(Jogador adv){
               
        try {
            proxy.enviaJogada(adv);
            return true;
        } catch (NaoJogandoException ex) {
            Logger.getLogger(AtorRede.class.getName()).log(Level.SEVERE, null, ex);
        }    
        return false;
    }
    
    @Override
    public void finalizarPartidaComErro(String message) {
        JOptionPane.showMessageDialog(null, "Partida encerrada");
        abaloneView.getApp().appEncerrarPartida();
        abaloneView.getApp().appDesconectar();
        abaloneView.getTabuleiroView().resetTabuleiro();
    }

    @Override
    public void receberMensagem(String msg) {
         abaloneView.getMsgPanel().receberMensagemRede(msg);
    }

    @Override
    public void receberJogada(Jogada jogada) {
        
        if(jogada instanceof Mensagem){
            Mensagem msg = (Mensagem) jogada;
            abaloneView.getMsgPanel().receberMensagemRede(msg.getMensagem());     
        }
        
        if(jogada instanceof JogadaAbalone){
            
            abaloneView.getApp().getJogadorLocal().setJogadorDaVez(true);
            JogadaAbalone ja = (JogadaAbalone) jogada;
            abaloneView.getTabuleiroView().setPosicoes(ja.getPosicoes());
            abaloneView.getTabuleiroView().rePaint(); 
            
            if(ja.getJogador().isVencedor()){
                JOptionPane.showMessageDialog(null, "Vencedor:" + ja.getJogador().getNome());
                desconectar();
            }
            abaloneView.getApp().avaliarVencedor();
            abaloneView.getTabuleiroView().verificaVencedor();
            
        } 
        
        if(jogada instanceof Jogador){
            Jogador jog = (Jogador) jogada;
            
            if(jog.isJogadorDaVez()){       
                abaloneView.getTabuleiroView().setPrimeiroAJogar(true);          
            } else{            
                abaloneView.getTabuleiroView().setPrimeiroAJogar(false);      
            }
            abaloneView.getApp().appIniciarPartida();
            abaloneView.getTabuleiroView().setPartidaIniciada(true);
            abaloneView.getTabuleiroView().getApp().setJogadorAdvesario(jog);
            abaloneView.getTabuleiroView().rePaint();
        }
        
    }

    @Override
    public void tratarConexaoPerdida() {
        JOptionPane.showMessageDialog(null, "Partida encerrada");
        abaloneView.getApp().appEncerrarPartida();
        abaloneView.getApp().appDesconectar();
        abaloneView.getTabuleiroView().resetTabuleiro();
    }

    @Override
    public void tratarPartidaNaoIniciada(String message) {
        JOptionPane.showMessageDialog(null, "Partida não iniciada");
    }
   
    public void desconectar(){
        try {          
            proxy.desconectar();
        } catch (NaoConectadoException ex) {
            Logger.getLogger(AtorRede.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void iniciarNovaPartida(Integer posicao)  {
        
        Jogador jog = abaloneView.getApp().getJogadorLocal();
        
        if(posicao == 1){
            jog.setJogadorDaVez(true);
        } else if(posicao == 2){            
            jog.setJogadorDaVez(false);       
        }     
        
        enviarJogada(jog);
    }
    
    public void encerrarPartida(){
        try {
            proxy.finalizarPartida();
        } catch (NaoConectadoException ex) {
            Logger.getLogger(AtorRede.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NaoJogandoException ex) {
            Logger.getLogger(AtorRede.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public AbaloneView getAbaloneView() {
        return abaloneView;
    }
    
    
    
}
